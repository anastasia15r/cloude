# Hands-on: автоматизированная обработка заказов

## Цель и предварительные условия
Создать Standard Workflow в Frankfurt, проверить четыре маршрута и научиться анализировать историю исполнения. Нужен AWS-аккаунт с разрешениями администратора на предварительную настройку IAM и учебный пользователь с ограниченными правами. До начала согласуйте сервис с преподавателем, проверьте ZeroSpend и стоимость в Pricing Calculator (6 запусков × 6 переходов, 0 USD при свободной квоте).

## 1. Настройка IAM
Администратор создаёт customer-managed policy `ind-stepfunctions-policy` из [шаблона](iam-policy.example.json), заменяя ACCOUNT_ID собственным номером аккаунта только локально. Создайте группу `ind-stepfunctions-group`, прикрепите политику к группе и добавьте учебного пользователя. Не заменяйте существующие необходимые разрешения пользователя без согласования. Политика ограничивает управление машинами префиксом ind- и регионом Frankfurt.

![Политика создана](screenshots/policy-created.png)
![Группа создана](screenshots/group-created.png)

Создайте роль `ind-stepfunctions-role` с доверительной политикой [trust-policy.json](trust-policy.json). Для состояний Pass, Choice, Fail и Succeed дополнительных разрешений на внешние сервисы не требуется. Добавьте тег Lab=individual к роли и политике; группы IAM не поддерживают теги. Не создавайте ключи доступа.

![Роль создана](screenshots/role-created.png)
![Доверительная политика](screenshots/trust-policy.png)

## 2. Создание машины состояний
1. Войдите учебным пользователем, выберите Europe (Frankfurt), откройте Step Functions → State machines → Create state machine.
2. Выберите Create from blank, имя `ind-order-workflow`, тип Standard, Continue.
3. В Design выберите JSONPath; в Code вставьте содержимое [workflow.asl.json](workflow.asl.json). Это воспроизводимая версия показанного процесса. Проверьте граф и отсутствие ошибок определения.
4. В Config выберите существующую роль `ind-stepfunctions-role`, Logging OFF, X-Ray выключен, без customer-managed KMS key. Добавьте тег Lab=individual. Нажмите Create.

![Тип процесса](screenshots/workflow-type.png)
![Тег](screenshots/tags.png)
![Созданный процесс](screenshots/workflow-created.png)

## 3. Проверка результата
Откройте машину состояний → Start execution (или Execute в редакторе). Для каждого примера запускайте отдельное исполнение с новым именем по умолчанию. Откройте Execution input and output и Graph view.

### Тест 1 — обычный заказ
```json
{"orderId":"ORD-001","amount":250,"inStock":true}
```
Ожидается Succeeded, result.status=ACCEPTED, result.priority=STANDARD.

![Результат](screenshots/standard-result.png)

### Тест 2 — приоритетный заказ
```json
{"orderId":"ORD-002","amount":1500,"inStock":true}
```
Ожидается Succeeded, ACCEPTED, HIGH.

![Результат](screenshots/priority-result.png)

### Тест 3 — товара нет
```json
{"orderId":"ORD-003","amount":500,"inStock":false}
```
Ожидается Succeeded, REJECTED, Product is out of stock.

![Результат](screenshots/rejected-result.png)

### Тест 4 — что будет, если нет суммы
```json
{"orderId":"ORD-004","inStock":true}
```
Ожидается Failed, InvalidOrderData, Missing or invalid order parameters. Раскройте Cause и откройте Graph view: ValidateOrder выбирает Default → InvalidOrder. Отсутствие amount не позволяет выполнить проверку суммы.

![Вход](screenshots/invalid-input.png)
![Ошибка](screenshots/invalid-cause.png)
![Граф](screenshots/invalid-graph.png)

Вернитесь к списку Executions: три Succeeded и один Failed. Если консоль не открывает подробности из-за AccessDenied, администратор должен проверить `states:DescribeStateMachineForExecution` на ARN исполнения и `states:DescribeExecution`, `states:GetExecutionHistory`. Не выдавайте AdministratorAccess ради просмотра.

![История](screenshots/execution-list.png)

## 4. Удаление ресурсов — после защиты
1. Откройте Resource Groups → Tag Editor, выберите Frankfurt, найдите ресурсы по Lab=individual. Проверьте также глобальные IAM-ресурсы в IAM, поскольку не все типы доступны в Tag Editor.
2. Удалите `ind-order-workflow` через Step Functions (если Tag Editor не предоставляет прямого удаления, используйте ссылку на консоль ресурса).
3. Администратор удаляет учебного пользователя из созданной группы, отсоединяет только созданную для работы политику, удаляет группу, роль и политику, если они больше нигде не используются. Не удаляйте самого учебного пользователя или ZeroSpend.
4. Через день проверьте Billing and Cost Management → Bills. При недостатке прав обратитесь к администратору.

На момент подготовки отчёта удаление ещё не выполнялось: ресурсы нужны для защиты. Наличие тегов IAM следует дополнительно проверить.
