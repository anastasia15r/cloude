# Лабораторная работа №4 — Amazon S3: объектное хранилище

**Студент:** Плотник Анастасия  
**Группа:** IA204  
**Специальность:** Прикладная информатика  
**Уровень:** базовый  
**Регион AWS:** `eu-central-1` (Frankfurt)  
**S3-бакет:** `timecapsule-dev-uploads-anastasiaplotnic`

## Цель работы

Освоить создание и настройку Amazon S3, управление объектами через веб-консоль и AWS CLI, ограничение доступа, версионирование, правила жизненного цикла и временные подписанные ссылки. В отчёте отражены выполненные действия и наблюдавшиеся результаты; скриншоты собраны в папке `images/`.

## Задание 1. Создание и первичная настройка бакета

В AWS Console создан бакет типа **General purpose** с глобальным пространством имён в регионе `eu-central-1`. Установлены **ACLs disabled (Bucket owner enforced)**, **Block all public access**, шифрование **SSE-S3**. Первоначально версионирование было отключено. Для организации ресурсов добавлены теги `Name=timecapsule-dev-uploads`, `Project=timecapsule`, `Environment=dev`, `Owner=anastasiaplotnic`, `Lab=lab4`.

![Настройки создания бакета](images/image(20261101-183701).png)

*Рисунок — Настройки создания бакета.*
![Параметры владения объектами и блокировка публичного доступа](images/image(20261101-184905).png)

*Рисунок — Параметры владения объектами и блокировка публичного доступа.*
![Версионирование при создании](images/image(20261101-185143).png)

*Рисунок — Версионирование при создании.*
![Теги бакета](images/image(20261101-185347).png)

*Рисунок — Теги бакета.*
![Шифрование и создание бакета](images/image(20261101-185416).png)

*Рисунок — Шифрование и создание бакета.*

В бакете созданы префиксы `uploads/` и `backups/`; в `uploads/` загружены изображения, а в `backups/` — текстовый файл. В S3 «папки» являются логическими префиксами ключей объектов, а не отдельными каталогами файловой системы.

![Созданы префиксы uploads и backups](images/image(20261101-185538).png)

*Рисунок — Созданы префиксы uploads и backups.*
![Содержимое uploads](images/image(20261101-185747).png)

*Рисунок — Содержимое uploads.*
![Содержимое backups](images/image(20261101-190045).png)

*Рисунок — Содержимое backups.*

**Вопрос: зачем нужны Block Public Access и ACLs disabled?** Первый механизм помогает предотвратить случайную публичную публикацию объектов. Отключение ACL упрощает управление правами: владелец бакета контролирует объекты, а доступ задаётся политиками IAM и бакета.

**Вопрос: что такое теги?** Это пары «ключ–значение» для поиска, группировки, контроля затрат и управления ресурсами. Теги не заменяют политики доступа.

## Задание 2. Работа с объектами и их свойствами

В консоли проверены свойства изображения: ключ объекта, S3 URI, ARN, размер, тип, ETag и системные метаданные. Для JPG указан `Content-Type: image/jpeg`. Попытка открыть обычный Object URL приватного файла без авторизации привела к `AccessDenied` — ожидаемое поведение при включённой блокировке публичного доступа.

![Свойства объекта и S3 URI](images/image(20261101-190557).png)

*Рисунок — Свойства объекта и S3 URI.*
![Состояние версионирования объекта](images/image(20261101-190726).png)

*Рисунок — Состояние версионирования объекта.*
![Метаданные и Object Lock](images/image(20261101-191202).png)

*Рисунок — Метаданные и Object Lock.*
![AccessDenied при открытии обычного URL](images/image(20261101-191750).png)

*Рисунок — AccessDenied при открытии обычного URL.*

**Вопрос: чем отличаются S3 URI, Object URL и ключ?** `s3://bucket/key` используется в AWS CLI; HTTPS Object URL предназначен для сетевых запросов; ключ (`uploads/photo.txt`) однозначно обозначает объект внутри бакета. Наличие URL не означает разрешение на чтение.

## Задание 3. AWS CLI и операции с файлами

Для ежедневной работы создан IAM-пользователь `anastasia-labs` с разрешением `AmazonS3FullAccess` и возможностью смены пароля. После входа под IAM-пользователем работа продолжена в CloudShell. Команда `aws sts get-caller-identity` подтвердила IAM-идентичность, а `aws s3 ls` показала содержимое бакета.

```bash
BUCKET=timecapsule-dev-uploads-anastasiaplotnic
echo "$BUCKET"
aws sts get-caller-identity
aws s3 ls "s3://$BUCKET/"
```

![IAM и подготовка пользователя](images/image(20261101-191950).png)

*Рисунок — IAM и подготовка пользователя.*
![Проверка IAM-идентичности и бакета через CloudShell](images/image(20261101-193509).png)

*Рисунок — Проверка IAM-идентичности и бакета через CloudShell.*

В CloudShell создана локальная структура `lab4/2026/10`, файлы `photo.txt`, `report.txt` и `report-2.txt`. Файлы загружены в S3, проверены через `ls --recursive`; метаданные объекта получены командой `head-object`, а загрузка обратно на локальную машину проверена через `aws s3 cp`.

```bash
mkdir -p ~/lab4/2026/10
cd ~/lab4
printf 'photo placeholder\n' > photo.txt
printf 'october report\n' > 2026/10/report.txt
printf 'october report 2\n' > 2026/10/report-2.txt
aws s3 cp photo.txt "s3://$BUCKET/uploads/photo.txt"
aws s3 cp 2026/10/ "s3://$BUCKET/uploads/2026/10/" --recursive
aws s3 ls "s3://$BUCKET/" --recursive
aws s3api head-object --bucket "$BUCKET" --key 'uploads/2026/10/report.txt'
aws s3 cp "s3://$BUCKET/uploads/photo.txt" downloaded.txt
cat downloaded.txt
aws s3 rm "s3://$BUCKET/uploads/2026/10/report-2.txt"
```

![Создание локальных тестовых файлов](images/image(20261101-194222).png)

*Рисунок — Создание локальных тестовых файлов.*
![Загрузка файлов в S3](images/image(20261101-194641).png)

*Рисунок — Загрузка файлов в S3.*
![Список объектов с ключами](images/image(20261101-194825).png)

*Рисунок — Список объектов с ключами.*
![Проверка свойств через head-object](images/image(20261101-195039).png)

*Рисунок — Проверка свойств через head-object.*
![Скачивание объекта через CLI](images/image(20261101-195142).png)

*Рисунок — Скачивание объекта через CLI.*
![Удаление тестового объекта](images/image(20261101-195354).png)

*Рисунок — Удаление тестового объекта.*

При первой попытке получить метаданные изображения команда `head-object` вернула `404 Not Found` из-за неточного ключа. После получения точного ключа из `list-objects-v2` операция выполнилась успешно.

**Вопрос: в чём разница между `aws s3` и `aws s3api`?** `aws s3` содержит удобные высокоуровневые команды (`cp`, `ls`, `rm`), а `aws s3api` предоставляет более детальный доступ к операциям API, например `head-object` и `list-object-versions`.

## Задание 4. Политика бакета и безопасный транспорт

В бакет добавлена политика **DenyInsecureTransport**: она запрещает действия `s3:*` с бакетом и его объектами, если `aws:SecureTransport` равно `false` (незащищённый HTTP). При попытке обратиться к S3 через HTTP получена ошибка `AccessDenied`, а запрос `get-bucket-policy` подтвердил сохранённую политику.

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "DenyInsecureTransport",
    "Effect": "Deny",
    "Principal": "*",
    "Action": "s3:*",
    "Resource": [
      "arn:aws:s3:::timecapsule-dev-uploads-anastasiaplotnic",
      "arn:aws:s3:::timecapsule-dev-uploads-anastasiaplotnic/*"
    ],
    "Condition": {"Bool": {"aws:SecureTransport": "false"}}
  }]
}
```

![Редактор политики бакета](images/image(20261101-195548).png)

*Рисунок — Редактор политики бакета.*
![Сообщение проверки IAM-политики в редакторе](images/image(20261101-195636).png)

*Рисунок — Сообщение проверки IAM-политики в редакторе.*
![Политика бакета сохранена](images/image(20261101-195854).png)

*Рисунок — Политика бакета сохранена.*
![Проверка доступа по HTTP: AccessDenied](images/image(20261101-200049).png)

*Рисунок — Проверка доступа по HTTP: AccessDenied.*
![Получение сохранённой политики](images/image(20261101-200144).png)

*Рисунок — Получение сохранённой политики.*

**Вопрос: почему HTTP запрещён, а HTTPS допустим?** При HTTPS соединение защищено TLS; политика явно запрещает незашифрованный транспорт. `Deny` имеет приоритет над разрешениями IAM, поэтому даже пользователь с `AmazonS3FullAccess` не может обойти этот запрет.

## Задание 5. Версионирование и Lifecycle Rules

Версионирование включено в свойствах бакета. Статус `Enabled` подтверждён через AWS CLI:

```bash
aws s3api get-bucket-versioning --bucket "$BUCKET"
```

![Включение версионирования](images/image(20261101-200239).png)

*Рисунок — Включение версионирования.*
![Версионирование успешно включено](images/image(20261101-200307).png)

*Рисунок — Версионирование успешно включено.*
![Проверка статуса Enabled через CLI](images/image(20261101-200331).png)

*Рисунок — Проверка статуса Enabled через CLI.*

Для проверки создан `uploads/version-test.txt`. Сначала загружена версия с содержимым `Version 1 - Original content`, затем тот же ключ перезаписан содержимым `Version 2 - Updated content`. `list-object-versions` показала разные идентификаторы версий и отметку `IsLatest` для текущей версии. Старая версия скачана по `version-id`, проверена командой `cat` и затем снова загружена как новая текущая версия.

```bash
printf 'Version 1 - Original content\n' > version-test.txt
aws s3 cp version-test.txt "s3://$BUCKET/uploads/version-test.txt"
printf 'Version 2 - Updated content\n' > version-test.txt
aws s3 cp version-test.txt "s3://$BUCKET/uploads/version-test.txt"
aws s3api list-object-versions --bucket "$BUCKET"   --prefix 'uploads/version-test.txt'   --query 'Versions[].[Key,VersionId,IsLatest,LastModified]' --output table
# Старый VersionId берётся из фактического вывода команды.
aws s3api get-object --bucket "$BUCKET"   --key 'uploads/version-test.txt' --version-id '<OLD_VERSION_ID>' restored-version.txt
cat restored-version.txt
aws s3 cp restored-version.txt "s3://$BUCKET/uploads/version-test.txt"
```

![Первая версия тестового файла](images/image(20261101-200613).png)

*Рисунок — Первая версия тестового файла.*
![Первая загрузка в бакет](images/image(20261101-200751).png)

*Рисунок — Первая загрузка в бакет.*
![Изменение содержимого файла](images/image(20261101-200845).png)

*Рисунок — Изменение содержимого файла.*
![Вторая загрузка](images/image(20261101-200944).png)

*Рисунок — Вторая загрузка.*
![Список версий объекта](images/image(20261101-201017).png)

*Рисунок — Список версий объекта.*
![Получение идентификатора старой версии](images/image(20261101-201249).png)

*Рисунок — Получение идентификатора старой версии.*
![Скачивание старой версии](images/image(20261101-201310).png)

*Рисунок — Скачивание старой версии.*
![Проверка восстановленного содержимого](images/image(20261101-201336).png)

*Рисунок — Проверка восстановленного содержимого.*
![Возврат старого содержимого как новой текущей версии](images/image(20261101-201439).png)

*Рисунок — Возврат старого содержимого как новой текущей версии.*
![Проверка истории версий после восстановления](images/image(20261101-201506).png)

*Рисунок — Проверка истории версий после восстановления.*

**Вопрос: чем восстановление отличается от удаления версии?** Восстановление старого содержимого новой загрузкой создаёт очередную текущую версию, сохраняя историю. Удаление конкретной версии удаляет её данные без возможности восстановить именно эту версию через S3 Versioning.

В разделе **Management → Lifecycle rules** создано правило `cleanup-old-test-versions`, действующее только для префикса `uploads/version-test.txt`. Правило удаляет **нетекущие версии спустя 30 дней**; текущую версию оно не удаляет. Статус и параметры подтверждены через CLI:

```bash
aws s3api get-bucket-lifecycle-configuration --bucket "$BUCKET"
```

```json
{
  "Rules": [{
    "ID": "cleanup-old-test-versions",
    "Filter": {"Prefix": "uploads/version-test.txt"},
    "Status": "Enabled",
    "NoncurrentVersionExpiration": {"NoncurrentDays": 30}
  }]
}
```

![Раздел правил жизненного цикла](images/image(20261101-201756).png)

*Рисунок — Раздел правил жизненного цикла.*
![Создание Lifecycle Rule](images/image(20261101-201819).png)

*Рисунок — Создание Lifecycle Rule.*
![Выбор действий над нетекущими версиями](images/image(20261101-201851).png)

*Рисунок — Выбор действий над нетекущими версиями.*
![Настройка срока 30 дней](images/image(20261101-201914).png)

*Рисунок — Настройка срока 30 дней.*
![Активное правило Lifecycle](images/image(20261101-201955).png)

*Рисунок — Активное правило Lifecycle.*
![Проверка параметров правила в CloudShell](images/image(20261101-202057).png)

*Рисунок — Проверка параметров правила в CloudShell.*

**Вопрос: зачем нужны Lifecycle Rules?** Для автоматического удаления устаревших версий и/или перевода объектов в другие классы хранения, что упрощает управление данными и помогает контролировать расходы. Само удаление через 30 дней не проверялось ожиданием: проверена корректность конфигурации.

## Задание 6. Подписанные URL (Presigned URLs)

**Шаг 1 — AWS Console.** Для JPG-изображения в `uploads/` создана временная подписанная ссылка. Изображение успешно открылось в режиме инкогнито, несмотря на приватность бакета. На предоставленном снимке окна создания ссылки указано **15 минут**; по условию задания требуется **5 минут**, поэтому при сдаче следует использовать ссылку с пятиминутным сроком, если настройка не была изменена до создания.

![Окно создания подписанной ссылки на JPG](images/image(20261101-202415).png)

*Рисунок — Окно создания подписанной ссылки на JPG.*
![Изображение открывается в приватном окне](images/image(20261101-202508).png)

*Рисунок — Изображение открывается в приватном окне.*

**Шаг 2 — AWS CLI.** Сгенерирована ссылка на `uploads/photo.txt` со сроком 120 секунд; в приватном окне получено содержимое `photo placeholder`.

```bash
aws s3 presign "s3://$BUCKET/uploads/photo.txt" --expires-in 120
```

![Проверка переменной бакета](images/image(20261101-203510).png)

*Рисунок — Проверка переменной бакета.*
![Создание подписанной ссылки через CLI](images/image(20261101-203607).png)

*Рисунок — Создание подписанной ссылки через CLI.*
![Успешное чтение photo.txt в инкогнито](images/image(20261101-203704).png)

*Рисунок — Успешное чтение photo.txt в инкогнито.*

**Шаг 3 — изменение ключа.** В подписанном URL путь `uploads/photo.txt` изменён на `uploads/notes.txt` без пересчёта подписи. S3 вернул `SignatureDoesNotMatch`.

![Ошибка SignatureDoesNotMatch после изменения ключа](images/image(20261101-204432).png)

*Рисунок — Ошибка SignatureDoesNotMatch после изменения ключа.*

**Шаг 4 — истечение срока.** После окончания срока исходная ссылка вернула `AccessDenied` и сообщение `Request has expired`.

![Ошибка Request has expired после 120 секунд](images/image(20261101-204706).png)

*Рисунок — Ошибка Request has expired после 120 секунд.*

### Ответы на контрольные вопросы задания 6

**Какие ошибки получены в шагах 3 и 4?** В шаге 3 — `SignatureDoesNotMatch`; в шаге 4 — `AccessDenied` с сообщением `Request has expired`.

**Почему нельзя просто поменять имя объекта в URL?** Подпись AWS Signature Version 4 вычисляется с учётом конкретного пути запроса и его параметров. Изменение ключа нарушает подпись.

**Обращалась ли команда `aws s3 presign` к S3 при создании ссылки?** Нет, сам URL формируется и подписывается локально на основе доступных учётных данных. Запрос к S3 выполняется при последующем открытии URL.

## Очистка временных данных

По завершении базовой части выполнена команда:

```bash
cd ~ && rm -rf lab4
```

Команда удаляет локальную папку `lab4` в CloudShell, но не удаляет бакет или объекты S3. Бакет оставлен для дальнейшей работы.

![Очистка локальной папки lab4](images/image(20261101-204752).png)

*Рисунок — Очистка локальной папки lab4.*

## Вывод

В базовой части лабораторной работы изучены создание приватного S3-бакета, операции с объектами через консоль и CLI, IAM-доступ, политика принудительного HTTPS, восстановление версий, автоматическое удаление старых версий и ограниченные по времени подписанные ссылки. Практические проверки продемонстрировали, что доступ к объекту зависит от политики безопасности, корректности подписи и срока действия ссылки.

## Приложение — полный комплект скриншотов

Ниже приведены все скриншоты из текущей практической работы в хронологическом порядке. Часть из них также размещена непосредственно в соответствующих разделах отчёта. При публикации репозитория рекомендуется скрыть полные значения временных токенов и подписанных URL, если они попали на изображения.

<details><summary>Скриншот 01 — image(20261101-183701).png</summary>

![Скриншот 01](images/image(20261101-183701).png)

</details>

<details><summary>Скриншот 02 — image(20261101-184905).png</summary>

![Скриншот 02](images/image(20261101-184905).png)

</details>

<details><summary>Скриншот 03 — image(20261101-185143).png</summary>

![Скриншот 03](images/image(20261101-185143).png)

</details>

<details><summary>Скриншот 04 — image(20261101-185347).png</summary>

![Скриншот 04](images/image(20261101-185347).png)

</details>

<details><summary>Скриншот 05 — image(20261101-185416).png</summary>

![Скриншот 05](images/image(20261101-185416).png)

</details>

<details><summary>Скриншот 06 — image(20261101-185538).png</summary>

![Скриншот 06](images/image(20261101-185538).png)

</details>

<details><summary>Скриншот 07 — image(20261101-185747).png</summary>

![Скриншот 07](images/image(20261101-185747).png)

</details>

<details><summary>Скриншот 08 — image(20261101-190045).png</summary>

![Скриншот 08](images/image(20261101-190045).png)

</details>

<details><summary>Скриншот 09 — image(20261101-190557).png</summary>

![Скриншот 09](images/image(20261101-190557).png)

</details>

<details><summary>Скриншот 10 — image(20261101-190726).png</summary>

![Скриншот 10](images/image(20261101-190726).png)

</details>

<details><summary>Скриншот 11 — image(20261101-191202).png</summary>

![Скриншот 11](images/image(20261101-191202).png)

</details>

<details><summary>Скриншот 12 — image(20261101-191750).png</summary>

![Скриншот 12](images/image(20261101-191750).png)

</details>

<details><summary>Скриншот 13 — image(20261101-191950).png</summary>

![Скриншот 13](images/image(20261101-191950).png)

</details>

<details><summary>Скриншот 14 — image(20261101-193509).png</summary>

![Скриншот 14](images/image(20261101-193509).png)

</details>

<details><summary>Скриншот 15 — image(20261101-193919).png</summary>

![Скриншот 15](images/image(20261101-193919).png)

</details>

<details><summary>Скриншот 16 — image(20261101-194222).png</summary>

![Скриншот 16](images/image(20261101-194222).png)

</details>

<details><summary>Скриншот 17 — image(20261101-194641).png</summary>

![Скриншот 17](images/image(20261101-194641).png)

</details>

<details><summary>Скриншот 18 — image(20261101-194825).png</summary>

![Скриншот 18](images/image(20261101-194825).png)

</details>

<details><summary>Скриншот 19 — image(20261101-195039).png</summary>

![Скриншот 19](images/image(20261101-195039).png)

</details>

<details><summary>Скриншот 20 — image(20261101-195142).png</summary>

![Скриншот 20](images/image(20261101-195142).png)

</details>

<details><summary>Скриншот 21 — image(20261101-195354).png</summary>

![Скриншот 21](images/image(20261101-195354).png)

</details>

<details><summary>Скриншот 22 — image(20261101-195449).png</summary>

![Скриншот 22](images/image(20261101-195449).png)

</details>

<details><summary>Скриншот 23 — image(20261101-195548).png</summary>

![Скриншот 23](images/image(20261101-195548).png)

</details>

<details><summary>Скриншот 24 — image(20261101-195636).png</summary>

![Скриншот 24](images/image(20261101-195636).png)

</details>

<details><summary>Скриншот 25 — image(20261101-195854).png</summary>

![Скриншот 25](images/image(20261101-195854).png)

</details>

<details><summary>Скриншот 26 — image(20261101-200049).png</summary>

![Скриншот 26](images/image(20261101-200049).png)

</details>

<details><summary>Скриншот 27 — image(20261101-200144).png</summary>

![Скриншот 27](images/image(20261101-200144).png)

</details>

<details><summary>Скриншот 28 — image(20261101-200239).png</summary>

![Скриншот 28](images/image(20261101-200239).png)

</details>

<details><summary>Скриншот 29 — image(20261101-200307).png</summary>

![Скриншот 29](images/image(20261101-200307).png)

</details>

<details><summary>Скриншот 30 — image(20261101-200331).png</summary>

![Скриншот 30](images/image(20261101-200331).png)

</details>

<details><summary>Скриншот 31 — image(20261101-200613).png</summary>

![Скриншот 31](images/image(20261101-200613).png)

</details>

<details><summary>Скриншот 32 — image(20261101-200751).png</summary>

![Скриншот 32](images/image(20261101-200751).png)

</details>

<details><summary>Скриншот 33 — image(20261101-200845).png</summary>

![Скриншот 33](images/image(20261101-200845).png)

</details>

<details><summary>Скриншот 34 — image(20261101-200944).png</summary>

![Скриншот 34](images/image(20261101-200944).png)

</details>

<details><summary>Скриншот 35 — image(20261101-201017).png</summary>

![Скриншот 35](images/image(20261101-201017).png)

</details>

<details><summary>Скриншот 36 — image(20261101-201056).png</summary>

![Скриншот 36](images/image(20261101-201056).png)

</details>

<details><summary>Скриншот 37 — image(20261101-201249).png</summary>

![Скриншот 37](images/image(20261101-201249).png)

</details>

<details><summary>Скриншот 38 — image(20261101-201310).png</summary>

![Скриншот 38](images/image(20261101-201310).png)

</details>

<details><summary>Скриншот 39 — image(20261101-201336).png</summary>

![Скриншот 39](images/image(20261101-201336).png)

</details>

<details><summary>Скриншот 40 — image(20261101-201439).png</summary>

![Скриншот 40](images/image(20261101-201439).png)

</details>

<details><summary>Скриншот 41 — image(20261101-201506).png</summary>

![Скриншот 41](images/image(20261101-201506).png)

</details>

<details><summary>Скриншот 42 — image(20261101-201534).png</summary>

![Скриншот 42](images/image(20261101-201534).png)

</details>

<details><summary>Скриншот 43 — image(20261101-201554).png</summary>

![Скриншот 43](images/image(20261101-201554).png)

</details>

<details><summary>Скриншот 44 — image(20261101-201619).png</summary>

![Скриншот 44](images/image(20261101-201619).png)

</details>

<details><summary>Скриншот 45 — image(20261101-201729).png</summary>

![Скриншот 45](images/image(20261101-201729).png)

</details>

<details><summary>Скриншот 46 — image(20261101-201756).png</summary>

![Скриншот 46](images/image(20261101-201756).png)

</details>

<details><summary>Скриншот 47 — image(20261101-201819).png</summary>

![Скриншот 47](images/image(20261101-201819).png)

</details>

<details><summary>Скриншот 48 — image(20261101-201851).png</summary>

![Скриншот 48](images/image(20261101-201851).png)

</details>

<details><summary>Скриншот 49 — image(20261101-201914).png</summary>

![Скриншот 49](images/image(20261101-201914).png)

</details>

<details><summary>Скриншот 50 — image(20261101-201955).png</summary>

![Скриншот 50](images/image(20261101-201955).png)

</details>

<details><summary>Скриншот 51 — image(20261101-202057).png</summary>

![Скриншот 51](images/image(20261101-202057).png)

</details>

<details><summary>Скриншот 52 — image(20261101-202415).png</summary>

![Скриншот 52](images/image(20261101-202415).png)

</details>

<details><summary>Скриншот 53 — image(20261101-202508).png</summary>

![Скриншот 53](images/image(20261101-202508).png)

</details>

<details><summary>Скриншот 54 — image(20261101-202521).png</summary>

![Скриншот 54](images/image(20261101-202521).png)

</details>

<details><summary>Скриншот 55 — image(20261101-202531).png</summary>

![Скриншот 55](images/image(20261101-202531).png)

</details>

<details><summary>Скриншот 56 — image(20261101-202817).png</summary>

![Скриншот 56](images/image(20261101-202817).png)

</details>

<details><summary>Скриншот 57 — image(20261101-202911).png</summary>

![Скриншот 57](images/image(20261101-202911).png)

</details>

<details><summary>Скриншот 58 — image(20261101-203000).png</summary>

![Скриншот 58](images/image(20261101-203000).png)

</details>

<details><summary>Скриншот 59 — image(20261101-203510).png</summary>

![Скриншот 59](images/image(20261101-203510).png)

</details>

<details><summary>Скриншот 60 — image(20261101-203607).png</summary>

![Скриншот 60](images/image(20261101-203607).png)

</details>

<details><summary>Скриншот 61 — image(20261101-203704).png</summary>

![Скриншот 61](images/image(20261101-203704).png)

</details>

<details><summary>Скриншот 62 — image(20261101-203807).png</summary>

![Скриншот 62](images/image(20261101-203807).png)

</details>

<details><summary>Скриншот 63 — image(20261101-203817).png</summary>

![Скриншот 63](images/image(20261101-203817).png)

</details>

<details><summary>Скриншот 64 — image(20261101-204432).png</summary>

![Скриншот 64](images/image(20261101-204432).png)

</details>

<details><summary>Скриншот 65 — image(20261101-204706).png</summary>

![Скриншот 65](images/image(20261101-204706).png)

</details>

<details><summary>Скриншот 66 — image(20261101-204752).png</summary>

![Скриншот 66](images/image(20261101-204752).png)

</details>

